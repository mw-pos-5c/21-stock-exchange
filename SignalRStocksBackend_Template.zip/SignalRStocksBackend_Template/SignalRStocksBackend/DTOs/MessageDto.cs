﻿namespace SignalRStocksBackend.DTOs;

public class MessageDto
{
    public string Msg { get; set; } = String.Empty;
}
