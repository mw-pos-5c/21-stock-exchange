﻿namespace SignalRStocksBackend.DTOs;

public class TickSpeedDto
{
    public int Speed { get; set; }
}
