﻿namespace SignalRStocksBackend.DTOs;

public class DepotDto
{
    public string ShareName { get; set; } = String.Empty;
    public int Amount { get; set; }
}